# Wikidata-Checker
A simple tool to see if movies are missing Wikidata properties

Displays a 'report' of the wikidata properties I use for my letterboxd-extras addon onto Letterboxd movies pages.
